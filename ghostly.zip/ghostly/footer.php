         </div>
         </div>
      </div>
   </div>
   </div>


   <footer class="blog-footer">
      <div class="container">
         <div class="row">
            <div class="col-xs-4">
               <span class="pull-left"><?php bloginfo('name'); ?></span><span class="pull-left">
            </div>
            <div class="col-xs-8">
               <span class="pull-left"><?php bloginfo('description'); ?></span>
            </div>
         </div>
      </div>
   </footer>
   
   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
   <!-- Include all compiled plugins (below), or include individual files as needed -->
   <script src="<?php bloginfo('template_url'); ?>/bootstrap.min.js"></script>

<?php wp_footer(); ?>
</body>

</html>